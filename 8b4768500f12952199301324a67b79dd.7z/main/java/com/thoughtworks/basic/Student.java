package com.thoughtworks.basic;

public class Student extends Person {
    private String name;
    private int age;
    private SchoolClass schoolClass;

    public Student(SchoolClass schoolClass) {
        this.schoolClass = schoolClass;
    }

    public Student(String name, int age, SchoolClass schoolClass) {
        super.setName(name);
        super.setAge(age);
        this.schoolClass = schoolClass;
    }

    public void changeName(String name) {
        super.setName(name);
        String notice = super.introduce() + " My name is " + name + " now.";
        schoolClass.getStudents().forEach(student -> {
            if (!this.equals(student)) {
                student.sendNotice(notice);
            }
        });
        schoolClass.getTeacher().sendNotice(notice);
    }


    public void changeClass(SchoolClass schoolClass) {
        String notice = super.introduce() + " I am a Student of Class " + schoolClass.getClassNum() + " now.";
        schoolClass.getStudents().forEach(student -> {
            if (!this.equals(student)) {
                student.sendNotice(notice);
            }
        });
        this.schoolClass.getTeacher().sendNotice(notice);

        schoolClass.getTeacher().sendNotice(notice);

        this.schoolClass.getStudents().forEach(student -> {
            if (!this.equals(student)) {
                student.sendNotice(notice);
            }
        });
    }

    public String introduce() {
        String result = super.introduce() + " I am a Student of Class " + schoolClass.getClassNum() + ".";

        return result;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public int getAge() {
        return super.getAge();
    }

    @Override
    public void setAge(int age) {
        super.setAge(age);
    }

    public SchoolClass getSchoolClass() {
        return schoolClass;
    }

    public void setSchoolClass(SchoolClass schoolClass) {
        this.schoolClass = schoolClass;
    }

}

package com.thoughtworks.basic;

import java.util.ArrayList;
import java.util.List;

public class SchoolClass {
    private int classNum;
    private Teacher teacher;
    private int stuNum;
    private List<Student> students = new ArrayList<>();

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public int getStuNum() {
        return stuNum;
    }

    public void setStuNum(int stuNum) {
        this.stuNum = stuNum;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public SchoolClass(int classNum) {
        this.classNum = classNum;
    }

    public int getClassNum() {
        return classNum;
    }

    public void setClassNum(int classNum) {
        this.classNum = classNum;
    }
}

package com.thoughtworks.basic;

public class Teacher extends Person{
    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public int getAge() {
        return super.getAge();
    }

    @Override
    public void setAge(int age) {
        super.setAge(age);
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    private String name;
    private int age;
    private String job = "Teacher";

    public String introduce() {
        String result = super.introduce() + " My job is " + job;
        return result;
    }
}

package com.thoughtworks.basic;

public class Dependency {
    public String say(){
        return "Leave me alone.";
    }
}

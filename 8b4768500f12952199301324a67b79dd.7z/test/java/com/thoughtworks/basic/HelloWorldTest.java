package com.thoughtworks.basic;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class HelloWorldTest {
    @Test
    public void SchoolClass_Test() {
        SchoolClass schoolClass = new SchoolClass(2);
        Student student = new Student("Cooper", 12, schoolClass);

        schoolClass.setClassNum(3);
        String result = student.introduce();

        assertEquals(result, "My name is Cooper. I am 12 years old. I am a Student of Class 3.");
    }


    @Test
    public void Student_test() {
        //given
        SchoolClass schoolClass = new SchoolClass(2);
        Student student = new Student(schoolClass);

        //when
        student.setAge(12);
        student.setName("Cooper");
        String actual = student.introduce();

        //then
        assertEquals(actual, "My name is Cooper. I am 12 years old. I am a Student of Class 2.");
    }

    @Test
    public void Person_test() {
        Person person = new Person();

        person.setAge(22);
        person.setName("Person");
        String string = person.introduce();

        assertEquals(string, "My name is Person. I am 22 years old.");
    }

    @Test
    public void Teacher_test() {
        //given
        Teacher teacher = new Teacher();

        //when
        teacher.setAge(12);
        teacher.setName("Cooper");
        String actual = teacher.introduce();

        //then
        assertEquals(actual, "My name is Cooper. I am 12 years old. My job is Teacher");
    }

    @Test
    public void hello_world_test() {
        //given
        Dependency dependency = new Dependency();
        HelloWorld helloWorld = new HelloWorld(dependency);

        //when
        String actual = helloWorld.beenCalled();

        //then
        assertEquals(actual, "Leave me alone.");
    }

    @Test
    public void should_be_mocked() {
        //given
        Dependency dependency = mock(Dependency.class);
        when(dependency.say()).thenReturn("Hello World");
        HelloWorld helloWorld = new HelloWorld(dependency);

        //when
        String actual = helloWorld.beenCalled();

        //then
        assertEquals(actual, "Hello World");
    }
}
